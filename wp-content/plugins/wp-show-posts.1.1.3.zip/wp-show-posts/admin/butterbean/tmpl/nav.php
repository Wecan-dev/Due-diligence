<a href="#butterbean-{{ data.manager }}-section-{{ data.name }}"><i class="{{ data.icon }}" aria-hidden="true"></i><span class="label">{{ data.label }}</span></a>
