<?php

// Core classes
include( ACFTC_PLUGIN_DIR_PATH . 'pro/core/locations.php');
include( ACFTC_PLUGIN_DIR_PATH . 'pro/core/field.php');
include( ACFTC_PLUGIN_DIR_PATH . 'pro/core/flexible-content-layout.php');

// Updates and licensing
include( ACFTC_PLUGIN_DIR_PATH . 'pro/updates/updates-action.php');
include( ACFTC_PLUGIN_DIR_PATH . 'pro/updates/updates.php');